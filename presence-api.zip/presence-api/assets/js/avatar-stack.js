/**
 * Overlapping avatar stack, client side.
 *
 * The counterpart to wp_presence_render_avatar_stack(). The network "Who's
 * Online" widget paints the stack server-side and then repaints it from a
 * Heartbeat tick, so the two renderers have to emit the same markup.
 *
 * @package Presence_API
 */
( function () {
	'use strict';

	function esc( str ) {
		const el = document.createElement( 'span' );
		el.textContent = str;
		// innerHTML leaves quotes alone, and these strings land in attributes too.
		return el.innerHTML.replace( /"/g, '&quot;' ).replace( /'/g, '&#039;' );
	}

	/**
	 * Builds an avatar stack.
	 *
	 * On `window` only because the two widgets' inline scripts are enqueued
	 * separately and have no other way to share it. Nothing outside the plugin
	 * is meant to call it.
	 *
	 * @private
	 * @param {Array}  users Users, each with an avatar_url and a display_name.
	 * @param {number} max   Maximum number of avatars to show.
	 * @return {string} HTML markup.
	 */
	window.wpPresenceBuildAvatarStack = function ( users, max ) {
		// get_avatar_url() returns false with the Show Avatars setting off.
		const shown = users.slice( 0, max ).filter( function ( user ) {
			return !! user.avatar_url;
		} );

		let html = '<span class="presence-avatar-stack">';

		// The avatars overlap, so the first one has to paint on top.
		shown.forEach( function ( user, index ) {
			html +=
				'<img src="' +
				esc( user.avatar_url ) +
				'" width="20" height="20" style="z-index:' +
				( shown.length - index ) +
				'" alt="' +
				esc( user.display_name ) +
				'" />';
		} );

		return html + '</span>';
	};
} )();

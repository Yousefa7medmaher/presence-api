/**
 * Active Posts dashboard widget client.
 *
 * @param {jQuery} $ The jQuery instance.
 * @package Presence_API
 */

( function ( $ ) {
	'use strict';

	if ( typeof wp === 'undefined' || typeof wp.heartbeat === 'undefined' ) {
		return;
	}

	const i18n = window.wpPresenceActivePosts || {};

	// Sitewide data, no per-tab context — the dedupe key is fixed.
	const pingContextKey = 'wp-presence-active-posts-ping';

	const tabCoordinator = window.wpPresenceCreateTabCoordinator(
		pingContextKey,
		[ 'presence-active-posts' ]
	);

	function esc( str ) {
		const el = document.createElement( 'span' );
		el.textContent = str;
		// innerHTML leaves quotes alone, and these strings land in attributes too.
		return el.innerHTML.replace( /"/g, '&quot;' ).replace( /'/g, '&#039;' );
	}

	$( document ).on( 'heartbeat-send', function ( event, data ) {
		if ( ! tabCoordinator.isLeader() ) {
			return;
		}
		data[ 'presence-active-posts-ping' ] = true;
	} );

	let lastSignature = '';

	function captureFocus( container ) {
		const active = document.activeElement;
		if ( ! active || ! $.contains( container[ 0 ], active ) ) {
			return null;
		}
		const item = $( active ).closest( '[data-post-id]' );
		return { postId: item.length ? item.data( 'post-id' ) : null };
	}

	function restoreFocus( container, info ) {
		if ( ! info ) {
			return;
		}
		let target = null;
		if ( info.postId !== null && info.postId !== undefined ) {
			target = container
				.find( '[data-post-id="' + info.postId + '"] a' )
				.first();
		}
		if ( target && target.length ) {
			target.trigger( 'focus' );
		} else {
			container.trigger( 'focus' );
		}
	}

	function buildFullPostsHtml( posts ) {
		let html =
			'<ul class="presence-active-posts-list" aria-label="' +
			esc( i18n.postsBeingEdited ) +
			'">';
		posts.forEach( function ( post ) {
			const anyActive = post.editors.some( function ( e ) {
				return e.status === 'active';
			} );
			const statusLabel = anyActive ? '' : i18n.statusIdle;
			html +=
				'<li class="presence-active-post-item" data-post-id="' +
				post.post_id +
				'">';
			html += '<span class="presence-editor-stack">';
			const stackMax = Math.min( post.editors.length, 4 );
			post.editors
				.slice( 0, stackMax )
				.forEach( function ( editor, idx ) {
					if ( editor.avatar_url ) {
						html +=
							'<img src="' +
							esc( editor.avatar_url ) +
							'" width="24" height="24" style="z-index:' +
							( stackMax - idx ) +
							'" alt="' +
							esc( editor.display_name ) +
							'" />';
					}
				} );
			html += '</span>';
			html += '<div class="presence-active-post-info">';
			html +=
				'<div><span class="presence-editor-count">' +
				esc( post.editor_label ) +
				'</span></div>';
			html +=
				'<div><span class="presence-post-title"><a href="' +
				esc( post.edit_url ) +
				'">' +
				esc( post.post_title ) +
				'</a></span></div>';
			html += '</div>';
			html +=
				'<span class="presence-status-text">' +
				esc( statusLabel ) +
				'</span>';
			html += '</li>';
		} );
		html += '</ul>';
		return html;
	}

	$( document ).on( 'heartbeat-tick', function ( event, data ) {
		if ( ! data[ 'presence-active-posts' ] ) {
			return;
		}

		const container = $( '#presence-active-posts-list' );
		if ( ! container.length ) {
			return;
		}

		const posts = data[ 'presence-active-posts' ];
		if ( ! posts.length ) {
			if ( lastSignature !== '' ) {
				const clearFocus = captureFocus( container );
				container.html( '<p>' + esc( i18n.noPostsEdited ) + '</p>' );
				restoreFocus( container, clearFocus );
				lastSignature = '';
			}
			return;
		}

		const sig = posts
			.map( function ( p ) {
				return (
					p.post_id +
					':' +
					p.editors
						.map( function ( e ) {
							return e.user_id + '/' + e.status;
						} )
						.join( '+' )
				);
			} )
			.join( ',' );
		if ( sig !== lastSignature ) {
			const focusInfo = captureFocus( container );
			container.html( buildFullPostsHtml( posts ) );
			restoreFocus( container, focusInfo );
			lastSignature = sig;
		}
	} );
} )( jQuery );
